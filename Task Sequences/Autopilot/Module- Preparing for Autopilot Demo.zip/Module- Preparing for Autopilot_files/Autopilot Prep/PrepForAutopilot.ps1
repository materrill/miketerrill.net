﻿<#
.SYNOPSIS
PrepForAutopilot
.DESCRIPTION
This script is intended to be run via a schedule task following the Prepare Configuration Manager Client step in a task sequence.
It will clean up after the ccmsetup uninstall process and then run sysprep for Autopilot.
.CREATED BY
Mike Terrill

    24.06.19: Initial Release
    24.08.20: Change get-process ccmexec to tsmanager
    24.09.04: Added Windows Update registry clean up

#>
$Version = '24.08.20'
$LogFile = "$($Env:WinDir)\Temp\PrepForAutopilot.log"
$Component = "Script"
$RegistryKey = "HKLM:\SOFTWARE\OSD" 

function CMTraceLog {
         [CmdletBinding()]
    Param (
		    [Parameter(Mandatory=$false)]
		    $Message,
		    [Parameter(Mandatory=$false)]
		    $ErrorMessage,
		    [Parameter(Mandatory=$false)]
		    $Component = "Script",
		    [Parameter(Mandatory=$false)]
		    [int]$Type,
		    [Parameter(Mandatory=$false)]
		    $LogFile
	    )
    <#
    Type: 1 = Normal, 2 = Warning (yellow), 3 = Error (red)
    #>
	    $Time = Get-Date -Format "HH:mm:ss.ffffff"
	    $Date = Get-Date -Format "MM-dd-yyyy"
	    if ($ErrorMessage -ne $null) {$Type = 3}
	    if ($Component -eq $null) {$Component = " "}
	    if ($Type -eq $null) {$Type = 1}
	    $LogMessage = "<![LOG[$Message $ErrorMessage" + "]LOG]!><time=`"$Time`" date=`"$Date`" component=`"$Component`" context=`"`" type=`"$Type`" thread=`"`" file=`"`">"
	    $LogMessage.Replace("`0","") | Out-File -Append -Encoding UTF8 -FilePath $LogFile
    }

CMTraceLog -Message "Starting PrepForAutopilot.ps1" -Type 1 -LogFile $LogFile -Component $Component
CMTraceLog -Message "Script version $Version" -Type 1 -LogFile $LogFile -Component $Component

#Wait for the TS to finish
CMTraceLog -Message "Sleeping 60 seconds - waiting for the TS to finish" -Type 1 -LogFile $LogFile -Component $Component
Start-Sleep -Seconds 60

do {
    if ((Get-Process -Name ccmsetup -ErrorAction SilentlyContinue) -or (Get-Process -Name tsmanager -ErrorAction SilentlyContinue))
        {
        CMTraceLog -Message "CM Processes still running. Sleeping 60 seconds" -Type 1 -LogFile $LogFile -Component $Component
        $CMProcess = $true
        Start-Sleep -Seconds 60
        }
    else 
        {
        CMTraceLog -Message "CM Processes not detected" -Type 1 -LogFile $LogFile -Component $Component
        $CMProcess = $false
        }
    }
while ($CMProcess -eq $true)

$CCMSetup = "$env:windir\ccmsetup\ccmsetup.exe"
$CCMExec = "$env:windir\ccm\ccmexec.exe"
if (Test-Path $CCMSetup)
    {
    CMTraceLog -Message "Found $CCMSetup" -Type 1 -LogFile $LogFile -Component $Component
    CMTraceLog -Message "Running ccmsetup /uninstall" -Type 1 -LogFile $LogFile -Component $Component
    Start-Process -FilePath $CCMSetup -ArgumentList "/uninstall" -Wait
    
    Start-Sleep -Seconds 60

    # Stop the Service "SMS Agent Host" which is a Process "CcmExec.exe"
    $CCMExecServiceCheck = Get-Service -Name CcmExec -ErrorAction SilentlyContinue
    if ($CCMExecServiceCheck)
        {
        Stop-Process CcmExec -Force -Verbose
        Stop-Service CcmExec -Force -Verbose
        $CCMExecService = Get-WmiObject -Class Win32_Service -Filter "Name='CcmExec'"
        $CCMExecService.delete()
        }

    # Stop the Service "ccmsetup" which is also a Process "ccmsetup.exe" if it wasn't stopped in the services after uninstall
    Get-Process -Name ccmsetup -ErrorAction SilentlyContinue | Stop-Process -Force -Verbose
    Get-Service -Name ccmsetup -ErrorAction SilentlyContinue | Stop-Service -Force -Verbose

    }
else
    {
    CMTraceLog -Message "Did Not Find $CCMSetup" -Type 1 -LogFile $LogFile -Component $Component
    CMTraceLog -Message "Assuming CM Client Uninstall Completed" -Type 1 -LogFile $LogFile -Component $Component
    }

if (!(Test-Path $CCMExec))
    {
    # Delete the SMSTSLogs folder: "C:\SMSTSLog"
    if (Test-path "$($Env:SystemDrive)\SMSTSLog") {
        CMTraceLog -Message "Removing directory $($Env:SystemDrive)\SMSTSLog" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:SystemDrive)\SMSTSLog" -Force -Recurse -Confirm:$false -Verbose
        }

    # Delete the folder of the CM Client installation: "C:\Windows\CCM"
    if (Test-path "$($Env:WinDir)\CCM") {
        CMTraceLog -Message "Removing directory $($Env:WinDir)\CCM" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:WinDir)\CCM" -Force -Recurse -Confirm:$false -Verbose
        }

    # Delete the folder of the CCM Cache of all the packages and Applications that were downloaded and installed on the Computer: "C:\Windows\ccmcache"
    if (Test-path "$($Env:WinDir)\CCMCache") {
        CMTraceLog -Message "Removing directory $($Env:WinDir)\CCMCache" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:WinDir)\CCMCache" -Force -Recurse -Confirm:$false -Verbose
        }

    # Delete the folder of the CCMSetup files that were used to install the client: "C:\Windows\ccmsetup"
    if (Test-path "$($Env:WinDir)\CCMSetup") {
        CMTraceLog -Message "Removing directory $($Env:WinDir)\CCMSetup" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:WinDir)\CCMSetup" -Force -Recurse -Confirm:$false -Verbose
        }

    # Delete the folder of the Start Menu shortcut to Software Center: "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Configuration Manager\Configuration Manager"
    if (Test-path "$($Env:ProgramData)\Microsoft\Windows\Start Menu\Programs\Microsoft Configuration Manager\Configuration Manager") {
        CMTraceLog -Message "Removing directory $($Env:ProgramData)\Microsoft\Windows\Start Menu\Programs\Microsoft Configuration Manager\Configuration Manager" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:ProgramData)\Microsoft\Windows\Start Menu\Programs\Microsoft Configuration Manager\Configuration Manager" -Force -Recurse -Confirm:$false -Verbose
        }

    # Delete the file with the certificate GUID and SMS GUID that current Client was registered with
    if (Test-path "$($Env:WinDir)\smscfg.ini") {
        CMTraceLog -Message "Removing $($Env:WinDir)\smscfg.ini" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path "$($Env:WinDir)\smscfg.ini" -Force -Confirm:$false -Verbose}

    # Delete the certificate itself
    CMTraceLog -Message "Removing HKLM:\Software\Microsoft\SystemCertificates\SMS\Certificates\*" -Type 1 -LogFile $LogFile -Component $Component
    Remove-Item -Path 'HKLM:\Software\Microsoft\SystemCertificates\SMS\Certificates\*' -Force -Confirm:$false -Verbose

    # Remove all the registry keys associated with the CM Client that might not be removed by ccmsetup.exe
    if (test-path 'HKLM:\SOFTWARE\Microsoft\CCM') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Microsoft\CCM" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\CCM' -Force -Recurse -Verbose
        }
    if (test-path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\CCM') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Wow6432Node\Microsoft\CCM" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\CCM' -Force -Recurse -Confirm:$false -Verbose
        }
    if (test-path 'HKLM:\SOFTWARE\Microsoft\SMS') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Microsoft\SMS" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\SMS' -Force -Recurse -Confirm:$false -Verbose
        }
    if (test-path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\SMS') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Wow6432Node\Microsoft\SMS" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\SMS' -Force -Recurse -Confirm:$false -Verbose
        }
    if (test-path 'HKLM:\Software\Microsoft\CCMSetup') {
        CMTraceLog -Message "Removing HKLM:\Software\Microsoft\CCMSetup" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\Software\Microsoft\CCMSetup' -Force -Recurse -Confirm:$false -Verbose
        }
    if (test-path 'HKLM:\Software\Wow6432Node\Microsoft\CCMSetup') {
        CMTraceLog -Message "Removing HKLM:\Software\Wow6432Node\Microsoft\CCMSetup" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\Software\Wow6432Node\Microsoft\CCMSetup' -Force -Confirm:$false -Recurse -Verbose
        }
    
    # Remove Windows Update registry keys that are left behind and will prevent WU from working
    if (test-path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Force -Confirm:$false -Recurse -Verbose
        }
    if (test-path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\GPCache') {
        CMTraceLog -Message "Removing HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\GPCache" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\GPCache' -Force -Confirm:$false -Recurse -Verbose
        }

    # Remove the service from "Services"
    if (test-path 'HKLM:\SYSTEM\CurrentControlSet\Services\CcmExec') {
        CMTraceLog -Message "Removing HKLM:\SYSTEM\CurrentControlSet\Services\CcmExec" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\CcmExec' -Force -Recurse -Confirm:$false -Verbose
        }
    if (test-path 'HKLM:\SYSTEM\CurrentControlSet\Services\ccmsetup') {
        CMTraceLog -Message "Removing HKLM:\SYSTEM\CurrentControlSet\Services\ccmsetup" -Type 1 -LogFile $LogFile -Component $Component
        Remove-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\ccmsetup' -Force -Recurse -Confirm:$false -Verbose
        }

    # Remove the Namespaces from the WMI repository
    CMTraceLog -Message "Removing any left over WMI entries (CCM/CCMVDI/SmsDm/sms)" -Type 1 -LogFile $LogFile -Component $Component
    Get-CimInstance -query "Select * From __Namespace Where Name='CCM'" -Namespace "root" | Remove-CimInstance -Verbose -Confirm:$false
    Get-CimInstance -query "Select * From __Namespace Where Name='CCMVDI'" -Namespace "root" | Remove-CimInstance -Verbose -Confirm:$false
    Get-CimInstance -query "Select * From __Namespace Where Name='SmsDm'" -Namespace "root" | Remove-CimInstance -Verbose -Confirm:$false
    Get-CimInstance -query "Select * From __Namespace Where Name='sms'" -Namespace "root\cimv2" | Remove-CimInstance -Verbose -Confirm:$false
    
    }

CMTraceLog -Message "Removing PrepForAutopilot Scheduled Task" -Type 1 -LogFile $LogFile -Component $Component
Unregister-ScheduledTask -TaskName "PrepForAutopilot" -Confirm:$False

#Check/Set Sysprep Reboot or Shutdown option
CMTraceLog -Message "Checking the Sysprep reboot/shutdown action" -Type 1 -LogFile $LogFile -Component $Component
If (Test-Path $RegistryKey) {
    $RegValues = Get-Item -Path $RegistryKey
    If ($RegValues.GetValue("SysprepRestartAction") -eq "shutdown") {
        $SysprepRestartAction = "shutdown"
        }
    Else {
        $SysprepRestartAction = "reboot"
        }
    }
Else {
    $SysprepRestartAction = "reboot"
    }
CMTraceLog -Message "Setting SysprepRestartAction to: $SysprepRestartAction" -Type 1 -LogFile $LogFile -Component $Component

CMTraceLog -Message "Running Sysprep" -Type 1 -LogFile $LogFile -Component $Component
$Sysprep = {C:\Windows\System32\Sysprep\Sysprep.exe /OOBE /$SysprepRestartAction /quiet}
& $Sysprep